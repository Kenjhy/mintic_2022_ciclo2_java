/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tallermintic01;

/**
 *
 * @author ASUS
 */
public class PropioCondicionales13 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println("Ajusta los valores voleanos segun gustes y prueba que hace: true o false");
        if(false)
        {
            System.out.println("Entro al if");
        }else if(false)
        {
            System.out.println("Entro al primer else if");
        }else if(true)
        {
            System.out.println("Entro al segundo else if");
        }else
        {
            System.out.println("Entro el esle, Condicion si no se cumplieron las anteriores");
        }
    }
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tallermintic01;

/**
 *
 * @author User
 */
public class DeterminarVocal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        char ch = 'i';

        switch (ch) {

            case 'a':

            case 'e':

            case 'i':

            case 'o':

            case 'u':

                System.out.println(ch + " Es vocal");

                break;

            default:

                System.out.println(ch + " No es vocal");

        }

    }

}

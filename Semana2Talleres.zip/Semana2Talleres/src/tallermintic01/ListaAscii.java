/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tallermintic01;

import tallermintic02.*;

/**
 *
 * @author WINDOWS 10
 */
public class ListaAscii {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        for (char car = 65; car <= 90; car++) {
            System.out.println("El caracter " + car + " es : " + (int) +car);
        }
    }

}

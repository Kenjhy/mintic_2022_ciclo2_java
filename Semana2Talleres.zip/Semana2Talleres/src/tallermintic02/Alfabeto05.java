/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tallermintic02;

import static java.lang.Character.toUpperCase;
import java.util.Scanner;

/**
 *
 * @author cristian.quiza
 */
public class Alfabeto05 {
    public static void main(String[] args){
//        char Min, May;
        char Min = 'a';
//        char May = 'A';

//        System.out.println( May + " - ");

        do 
        {
            System.out.print(Min + " - " ); 
            Min++;
        } 
        while(Min <= 'z');
//        System.out.println("-");
    }
        
  }
    
